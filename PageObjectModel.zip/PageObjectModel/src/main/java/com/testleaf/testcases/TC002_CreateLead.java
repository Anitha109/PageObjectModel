package com.testleaf.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testleaf.base.ProjectSpecificMethods;
import com.testleaf.pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethods {

	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
		testName = "Create Lead";
		testDescription = "Create lead with mandatory information";
		testAuthor = "Anitha";
		testCategory = "Smoke";
	}

	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password, String comName, String fName, String lName)
			throws IOException {

		new LoginPage().enterUserName(userName).enterPassword(password).clickLogin().clickCRMSFA().clickLeads()
				.clickCreateLead().enterCompanyName(comName).enterFirstName(fName).enterLastName(lName)
				.clickCreateLead();

	}

}
