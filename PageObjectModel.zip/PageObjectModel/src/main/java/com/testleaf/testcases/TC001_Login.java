package com.testleaf.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testleaf.base.ProjectSpecificMethods;
import com.testleaf.pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethods {

	@BeforeTest
	public void setData() {
		fileName = "Login";
		testName = "Create Lead";
		testDescription = "Create lead with mandatory information";
		testAuthor = "Anitha";
		testCategory = "Smoke";
	}

	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password) throws IOException {
		System.out.println(driver);
		 new LoginPage().enterUserName(userName).enterPassword(password).clickLogin();
		 

	}

}
