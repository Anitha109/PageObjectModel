package com.testleaf.pages;



import com.testleaf.base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{

//	public ViewLeadPage(ChromeDriver driver) {
//		this.driver = driver;
//	}
}
