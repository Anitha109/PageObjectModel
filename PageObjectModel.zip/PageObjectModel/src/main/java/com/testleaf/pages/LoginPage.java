package com.testleaf.pages;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.testleaf.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage enterUserName(String userName) throws IOException {
		driver.findElement(By.id("username")).sendKeys(userName);
		return this;
	}

	public LoginPage enterPassword(String password) throws IOException {
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}
	
	public HomePage clickLogin() throws IOException {
				driver.findElement(By.className("decorativeSubmit")).click();
				reportStep("Clicked on Login successfully", "pass");
					return new HomePage();
	}
}
